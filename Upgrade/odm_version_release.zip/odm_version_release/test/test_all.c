#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <signal.h>
#include <sys/fcntl.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
// Include all module headers
#include "odm_api_common.h"
#include "odm_api_error.h"
#include "odm_api_video.h"      /**< Video input/output API */
#include "odm_api_audio.h"      /**< Audio input/output API */
#include "odm_api_isp.h"        /**< Image Signal Processing API */
#include "odm_api_system.h"     /**< System management API */
#include "odm_api_network.h"    /**< Network configuration API */
#include "odm_api_event.h"      /**< Event detection API */
#include "odm_api_gpio.h"       /**< GPIO control API */
#include "odm_api_ptz.h"        /**< PTZ control API */
#include "odm_api_ota.h"        /**< Over-the-air update API */
#include "odm_api_ble.h"        /**< Bluetooth Low Energy API */
#include "odm_api_ircut.h"
#include "odm_api_gpio.h"

pthread_mutex_t media_mutex = PTHREAD_MUTEX_INITIALIZER;
void recvSignal(int sig)
{
    printf("[abnormal]: recv signal :%d\n",sig);
    system("dmesg");
    usleep(100*1000);
    printf("[abnormal]: ready sleep\n");
    do
    {
        usleep(1000*1000);
        exit(0);
    } while (1);
}

int init_media_recorder(const char *filename,FILE **media_file) {
   if (media_file == NULL) {
        printf("invalid media_file pointer\n");
        return -1;
    }
    *media_file = fopen(filename, "ab"); 
    if (!*media_file) {
        printf( "create file failed: %s\n", filename);
        return -1;
    }
    printf( "start record: %s\n", filename);
    return 0;
}

void write_video_frame(char *data,int data_len,FILE *media_file) {

    if (!data || data_len <= 0) { 
        printf("invalid data or data_len\n");
        return;
    }
    pthread_mutex_lock(&media_mutex);
    if (media_file) {
        size_t written = fwrite(data, 1, data_len, media_file);
        
        fflush(media_file);
        
        if (written != data_len) {
            printf("incomplete writing: %d/%d Bytes\n", 
                    written, data_len);
        }
    }
    pthread_mutex_unlock(&media_mutex);
}

void stop_recording(FILE **media_file) {
    pthread_mutex_unlock(&media_mutex);
    if (*media_file) {
        fflush(*media_file);      
        fsync(fileno(*media_file));
        fclose(*media_file);
        *media_file = NULL;
        printf("stop record\n");
    }
    pthread_mutex_unlock(&media_mutex);
}
FILE *media_file1=NULL;
FILE *media_file2=NULL;

// Video callback function for testing
void test_video_callback(const fca_video_in_frame_t *video_frame) {
    printf("Video callback1 received: size=%u, timestamp=%llu sequence:%d\n", 
           video_frame->size, video_frame->timestamp,video_frame->sequence);
    if(video_frame->sequence <200)
    {
        if(media_file1)
            write_video_frame(video_frame->data,video_frame->size,media_file1);
    }
    else
    {
        if(media_file1)
            stop_recording(&media_file1);
    }

}
void test_video_callback2(const fca_video_in_frame_t *video_frame) {
    printf("Video callback2 received: size=%u, timestamp=%llu sequence:%d\n", 
           video_frame->size, video_frame->timestamp,video_frame->sequence);
    if(video_frame->sequence <200)
    {
        if(media_file2)
            write_video_frame(video_frame->data,video_frame->size,media_file2);
    }
    else
    {
        if(media_file2)
            stop_recording(&media_file2);
    }

}
// QR code callback function for testing
void test_qrcode_callback(char *qrcode_str, int qrcode_len) {
    printf("QR code callback received: %s (len=%d)\n", qrcode_str, qrcode_len);
}
FILE *media_file3=NULL;
int test_audio_in_callback(const fca_audio_frame_t* audio_frame)
{
    printf("audio in callback received:size=%u,timestamp=%llu sequence:%d\n",audio_frame->size,audio_frame->timestamp,audio_frame->sequence);
    if(audio_frame->sequence < 500)
    {
        if(media_file3)
            write_video_frame(audio_frame->data,audio_frame->size,media_file3);

        // fca_audio_out_play_frame(audio_frame->data,audio_frame->size);
    }
    else
    {
        if(media_file3)
            stop_recording(&media_file3);
    }
    return 0;
}
void test_snapshot(void)
{
    printf("enter test_snapshot\n");
    char snapshot[15000]={0};
    int snaplength=0;
    int ret =fca_video_in_get_snapshot(snapshot,&snaplength);
    printf("fca_video_in_get_snapshot: %d length:%d\n", ret,snaplength);
    if(snaplength>0)
    {
        FILE *picture=NULL;
        init_media_recorder("/mnt/sd/snapshot1.jpeg",&picture);
        write_video_frame(snapshot,snaplength,picture);
        stop_recording(&picture);
    }

    return;
}
void* test_play_pcm_file(void *arg)
{
    int ret = fca_audio_out_play_file_block("/mnt/sd/audio1.wav");
    return (void*)ret;
}
void test_QR_CODE(void)
{
    printf("enter test_QR_CODE\n");
    int ret = fca_video_in_qrcode_scan_start(test_qrcode_callback);
    printf("fca_video_in_qrcode_scan_start: %d\n", ret);
    return;
}
void test_video()
{
    int ret=0;
    // Test video API
    printf("\n=== Testing Video API ===\n");
    ret = fca_video_in_init();
    printf("fca_video_in_init: %d\n", ret);
    
    fca_video_in_config_t config;
    config.codec = FCA_CODEC_VIDEO_H265;
    config.encoding_mode = FCA_VIDEO_ENCODING_MODE_VBR;
    config.bitrate_target = 1000;
    config.bitrate_max = 4000;
    config.gop = 3;
    config.fps = 15;
    config.width = 2304;
    config.height = 1296;
    config.max_qp = 28;
    config.min_qp = 42;
    
    ret = fca_video_in_set_config(0, &config);
    printf("fca_video_in_set_config: %d\n", ret);
    
    ret = fca_video_in_get_config(0, &config);
    printf("fca_video_in_get_config: %d\n", ret);

    init_media_recorder("/mnt/sd/video1.h265",&media_file1);
    ret = fca_video_in_start_callback(0, test_video_callback);
    printf("fca_video_in_start_callback: %d\n", ret);
    // The sub-stream is temporarily unavailable, while the QR code and screenshot function are temporarily not supported for calling.
    fca_video_in_config_t config2;
    config2.codec = FCA_CODEC_VIDEO_H264;
    config2.encoding_mode = FCA_VIDEO_ENCODING_MODE_VBR;
    config2.bitrate_target = 800;
    config2.bitrate_max = 4000;
    config2.gop = 3;
    config2.fps = 15;
    config2.width = 640;
    config2.height = 360;
    config2.max_qp = 28;
    config2.min_qp = 38;
    
    ret = fca_video_in_set_config(1, &config2);
    printf("fca_video_in_set_config: %d\n", ret);
    
    ret = fca_video_in_get_config(1, &config2);
    printf("fca_video_in_get_config: %d\n", ret);

    init_media_recorder("/mnt/sd/video2.h264",&media_file2);
    ret = fca_video_in_start_callback(1, test_video_callback2);
    printf("fca_video_in_start_callback: %d\n", ret);
    pthread_t snapshot;
    if(pthread_create(&snapshot,NULL,test_snapshot,NULL)!=0)
    {
        printf("create snapshot failed\n");
    }
    else
    {
        pthread_detach(snapshot);
        printf("create snapshot success\n");
    }
    pthread_t starQR;
    if(pthread_create(&starQR,NULL,test_QR_CODE,NULL)!=0)
    {
        printf("create starQR failed\n");
    }
    else
    {
        pthread_detach(starQR);
        printf("create starQR success\n");
    }
    while (media_file1 && media_file2)
    {
        sleep(1);
    }
    printf("\n=== Cleaning up ===\n");
    ret = fca_video_in_qrcode_scan_stop();
    printf("fca_video_in_qrcode_scan_stop: %d\n", ret);
    ret = fca_video_in_stop_callback(0);
    printf("fca_video_in_stop_callback: %d\n", ret);
    ret = fca_video_in_stop_callback(1);
    printf("fca_video_in_stop_callback2: %d\n", ret);
    
    ret = fca_video_in_uninit();
    printf("fca_video_in_uninit: %d\n", ret);

    return;
}
void test_audio()
{
    // Test audio API
    printf("\n=== Testing Audio API ===\n");
    int ret=0;
    ret = fca_audio_in_init();
    printf("fca_audio_in_init: %d\n", ret);
    ret = fca_audio_out_init();
    printf("fca_audio_out_init: %d\n", ret);
    int volume=80;

    fca_audio_config_t config={0};
    config.channel=1;
    config.codec=FCA_AUDIO_CODEC_AAC;
    config.format=16;
    config.rate=FCA_AUDIO_SAMPLE_RATE_8_KHZ;
    ret =fca_audio_in_set_config(0,&config);
    printf("fca_audio_in_set_config: %d\n", ret);
    ret =fca_audio_in_get_config(0,&config);

    ret = fca_set_audio_in_volume(volume);
    printf("fca_set_audio_in_volume: %d, volume=%d\n", ret, volume);
    ret = fca_get_audio_in_volume(&volume);
    printf("fca_get_audio_in_volume: %d, volume=%d\n", ret, volume);
    fca_audio_config_t config2={0};
    config2.channel=1;
    config2.codec=FCA_AUDIO_CODEC_AAC;
    config2.format=16;
    config2.rate=FCA_AUDIO_SAMPLE_RATE_8_KHZ;
    ret =fca_audio_out_set_config(&config);
    printf("fca_audio_out_set_config: %d\n", ret);
    ret =fca_audio_out_get_config(&config);
    printf("fca_audio_out_get_config: %d\n", ret);
    ret=fca_audio_out_set_volume(volume);
    printf("fca_audio_out_set_volume: %d, volume=%d\n", ret, volume);
    ret =fca_audio_out_get_volume(&volume);
    printf("fca_audio_out_get_volume: %d, volume=%d\n", ret, volume);
    init_media_recorder("/mnt/sd/audio1.aac",&media_file3);
    ret =fca_audio_in_start_callback(0,test_audio_in_callback);

    while (media_file3)
    {
        sleep(1);
    }
    ret =fca_audio_in_stop_callback(0);
    printf("fca_audio_in_stop_callback: %d\n", ret);
   
    /*
    Only PCM or ALAW formats are supported. 
    The audio file format is 16-bit bit depth, single-channel, 
    with an 8 kHz sampling rate.
    */
    pthread_t audio_out_task;
    int audio_ret=0;
    audio_ret=pthread_create(&audio_out_task,NULL,test_play_pcm_file,NULL);
    if(audio_ret)
    {
        printf("create audio out task failed\n");
    }
    else
    {
        int ret=0;
        // sleep(2);
        // fca_audio_out_stop();
        if(pthread_join(audio_out_task,(void*)ret))
        {
            printf("pthread_join failed\n");
        }

        printf("audio out ret:%d\n",ret);
    }
    // Clean up
    printf("\n=== Cleaning up ===\n");
    ret =fca_audio_in_uninit();
    printf("fca_audio_in_uninit: %d\n", ret);
    ret =fca_audio_out_uninit();
    printf("fca_audio_out_uninit: %d\n", ret);
    return;
}
// temporarily not supported
void Test_OTA()
{
    int ret=fca_sys_fw_ota("/mnt/sd/C9312_DSP_1.00.03-20251113_OTA.bin");
    printf("ret:%d\n",ret);
    return;
}
void test_ircut_video_callback(const fca_video_in_frame_t *video_frame) {
    // printf("Video callback1 received: size=%u, timestamp=%llu sequence:%d\n", 
    //        video_frame->size, video_frame->timestamp,video_frame->sequence);
    if(media_file1)
        write_video_frame(video_frame->data,video_frame->size,media_file1);

}
void ircut_record(void)
{
    int ret =0;

    init_media_recorder("/mnt/sd/video1.h264",&media_file1);
    ret = fca_video_in_start_callback(0, test_ircut_video_callback);
    printf("fca_video_in_start_callback: %d\n", ret);
    while (media_file1)
    {
        sleep(1);
    }
    printf("\n=== Cleaning up ===\n");
    ret = fca_video_in_stop_callback(0);
    printf("fca_video_in_stop_callback: %d\n", ret);

}
void ircut_callback(FCA_DAY_NIGHT_STATE_E state, const void *user_data) {
    printf("IRCut callback: current state = %s (user_data: %s)\n",
           state == FCA_DAY_STATE ? "DAY" : "NIGHT",
           (char*)user_data);
}
// Get the current time (in seconds, with decimal).
static double get_current_time() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

// Print test steps
static void print_step(int step, const char* desc) {
    printf("\n===== Step %d: %s =====\n", step, desc);
}

// Redesigned locking mechanism test function
static void test_lock_mechanism() {
    const int TEST_LOCK_CNT_TH = 3;    
    const int TEST_LOCK_TIME = 5; 
    const double TEST_TIME_WINDOW = 10.0;
    const int TEST_TRIGGER_INTERVAL = 2;

    int ret;
    FCA_DN_MODE_E current_mode;
    double start_time, current_time;

    printf("\n=== Starting Updated Lock Mechanism Test ===\n");
    printf("Test config: window=%.1fs, cnt_th=%d, lock_time=%ds, interval=%ds\n",
           TEST_TIME_WINDOW, TEST_LOCK_CNT_TH, TEST_LOCK_TIME, TEST_TRIGGER_INTERVAL);

    // Initialization: First, configure the IRCut settings (matching test parameters).
    fca_dn_attr_t test_config = {
        .lock_time = TEST_LOCK_TIME,
        .lock_cnt_th = TEST_LOCK_CNT_TH,
        .trigger_interval = TEST_TRIGGER_INTERVAL,
        // .day2night_threshold = 300, not support
        // .night2day_threshold = 500, not support
        .init_mode = FCA_DN_MODE_AUTO,
        .cb = ircut_callback,
        .user_data = "test_ircut"
    };
    ret = fca_dn_switch_set_config(&test_config);
    if (ret != 0) {
        printf("Failed to set test config, ret=%d\n", ret);
        return;
    }

    print_step(1, "Verify no lock when switches < threshold in window");
    start_time = get_current_time();
    for (int i = 0; i < TEST_LOCK_CNT_TH - 1; i++) {
        FCA_DN_MODE_E target = (i % 2 == 0) ? FCA_DN_MODE_DAY : FCA_DN_MODE_NIGHT;
        fca_dn_set_config_mode(target);
        fca_dn_get_config_mode(&current_mode);
        current_time = get_current_time();
        printf("Switch %d: target=%s, actual=%s (time=%.1fs)\n",
               i+1,
               target == FCA_DN_MODE_DAY ? "DAY" : "NIGHT",
               current_mode == FCA_DN_MODE_DAY ? "DAY" : "NIGHT",
               current_time - start_time);
        sleep(TEST_TRIGGER_INTERVAL);
    }

    fca_dn_set_config_mode(FCA_DN_MODE_AUTO);
    fca_dn_get_config_mode(&current_mode);
    printf("After %d switches: mode=%s (should be AUTO, no lock)\n",
           TEST_LOCK_CNT_TH - 1,
           current_mode == FCA_DN_MODE_AUTO ? "AUTO" : "ERROR");

    print_step(2, "Verify lock when switches >= threshold in window");
    start_time = get_current_time();
    for (int i = 0; i < TEST_LOCK_CNT_TH; i++) {
        FCA_DN_MODE_E target = (i % 2 == 0) ? FCA_DN_MODE_DAY : FCA_DN_MODE_NIGHT;
        fca_dn_set_config_mode(target);
        fca_dn_get_config_mode(&current_mode);
        current_time = get_current_time();
        printf("Switch %d: target=%s, actual=%s (time=%.1fs)\n",
               i+1,
               target == FCA_DN_MODE_DAY ? "DAY" : "NIGHT",
               current_mode == FCA_DN_MODE_DAY ? "DAY" : "NIGHT",
               current_time - start_time);
        if (i != TEST_LOCK_CNT_TH - 1) {
            sleep(TEST_TRIGGER_INTERVAL);
        }
    }

    fca_dn_set_config_mode(FCA_DN_MODE_AUTO);
    fca_dn_get_config_mode(&current_mode);
    printf("After %d switches: mode=%s (should remain last mode, locked)\n",
           TEST_LOCK_CNT_TH,
           current_mode == FCA_DN_MODE_AUTO ? "ERROR" : 
           (current_mode == FCA_DN_MODE_DAY ? "DAY" : "NIGHT"));

    print_step(3, "Verify no switch allowed during lock");
    current_time = get_current_time();
    printf("Lock started at %.1fs, duration %ds\n", current_time, TEST_LOCK_TIME);
    for (int i = 0; i < 2; i++) {
        FCA_DN_MODE_E target = (i % 2 == 0) ? FCA_DN_MODE_DAY : FCA_DN_MODE_NIGHT;
        fca_dn_set_config_mode(target);
        fca_dn_get_config_mode(&current_mode);
        printf("Attempt %d: target=%s, actual=%s (should not change)\n",
               i+1,
               target == FCA_DN_MODE_DAY ? "DAY" : "NIGHT",
               current_mode == FCA_DN_MODE_DAY ? "DAY" : "NIGHT");
        sleep(1); // short interval attempts
    }

    print_step(4, "Verify switch works after lock expires");
    printf("Waiting for lock to expire (%ds)...\n", TEST_LOCK_TIME);
    sleep(TEST_LOCK_TIME); 

    fca_dn_set_config_mode(FCA_DN_MODE_AUTO);
    fca_dn_get_config_mode(&current_mode);
    printf("After lock expires: mode=%s (should be AUTO)\n",
           current_mode == FCA_DN_MODE_AUTO ? "AUTO" : "ERROR");

    print_step(5, "Verify no lock when lock_time=0");
    test_config.lock_time = 0;
    fca_dn_switch_set_config(&test_config);
    for (int i = 0; i < TEST_LOCK_CNT_TH; i++) {
        FCA_DN_MODE_E target = (i % 2 == 0) ? FCA_DN_MODE_DAY : FCA_DN_MODE_NIGHT;
        fca_dn_set_config_mode(target);
        fca_dn_get_config_mode(&current_mode);
        printf("Switch %d (lock_time=0): target=%s, actual=%s (should succeed)\n",
               i+1,
               target == FCA_DN_MODE_DAY ? "DAY" : "NIGHT",
               current_mode == FCA_DN_MODE_DAY ? "DAY" : "NIGHT");
        sleep(TEST_TRIGGER_INTERVAL);
    }

    fca_dn_set_config_mode(FCA_DN_MODE_AUTO);
    fca_dn_get_config_mode(&current_mode);
    printf("After %d switches (lock_time=0): mode=%s (should be AUTO)\n",
           TEST_LOCK_CNT_TH,
           current_mode == FCA_DN_MODE_AUTO ? "AUTO" : "ERROR");

    printf("\n=== Updated Lock Mechanism Test Completed ===\n");
}

void Test_IrCut()
{
    int ret=-1;
    int value=-1;
    FCA_DN_MODE_E current_mode;
    FCA_DAY_NIGHT_STATE_E current_state;
    fca_dn_attr_t config = {0};
    fca_dn_attr_t get_config = {0};
    pthread_t record_thread;
    ret = fca_video_in_init();
    printf("fca_video_in_init: %d\n", ret);

    fca_video_in_config_t video_config;
    video_config.codec = FCA_CODEC_VIDEO_H264;
    video_config.encoding_mode = FCA_VIDEO_ENCODING_MODE_CBR;
    video_config.bitrate_target = 1000;
    video_config.bitrate_max = 4000;
    video_config.gop = 3;
    video_config.fps = 15;
    video_config.width = 2304;
    video_config.height = 1296;
    video_config.max_qp = 28;
    video_config.min_qp = 42;
    
    ret = fca_video_in_set_config(0, &video_config);
    printf("fca_video_in_set_config: %d\n", ret);
    
    ret = fca_video_in_get_config(0, &video_config);
    printf("fca_video_in_get_config: %d\n", ret);
    // record
    if(pthread_create(&record_thread, NULL, ircut_record, NULL) != 0)
	{
		printf("create record_thread error\n");
        return;
	}

    config.lock_time = 10;
    config.lock_cnt_th = 5;
    config.trigger_interval = 3;
    // config.day2night_threshold = 300; not support
    // config.night2day_threshold = 500; not support
    config.init_mode = FCA_DN_MODE_AUTO;
    config.cb = ircut_callback;
    config.user_data = "test_ircut";

    ret = fca_dn_switch_set_config(&config);
    printf("fca_dn_switch_set_config: %d\n", ret);

    // day mode
    printf("\n--- Setting to DAY mode ---\n");
    fca_dn_set_config_mode(FCA_DN_MODE_DAY);
    fca_dn_get_config_mode(&current_mode);
    printf("Current mode: %d (1=DAY)\n", current_mode);
    ret = fca_get_led_lighting(FCA_LIGHTING_LED_IR,&value);
    printf("fca_get_led_lighting: %d,ret:%d\n",value,ret);
    sleep(10);

    // night mode
    printf("\n--- Setting to NIGHT mode ---\n");
    fca_dn_set_config_mode(FCA_DN_MODE_NIGHT);
    fca_dn_get_config_mode(&current_mode);
    printf("Current mode: %d (2=NIGHT)\n", current_mode);
    sleep(1); 
    ret = fca_dn_get_current_env_status(&current_state);
    printf("Current environment state: %s\n",
           current_state == FCA_DAY_STATE ? "DAY" : "NIGHT");
    ret = fca_get_led_lighting(FCA_LIGHTING_LED_IR,&value);
    printf("fca_get_led_lighting: %d,ret:%d\n",value,ret);
    sleep(10); 

    // lock test
    test_lock_mechanism();


    //auto mode
    printf("\n--- Setting to AUTO mode ---\n");
    fca_dn_set_config_mode(FCA_DN_MODE_AUTO);
    fca_dn_get_config_mode(&current_mode);
    printf("Current mode: %d (0=AUTO)\n", current_mode);
    sleep(30); 

    // env status
    ret = fca_dn_get_current_env_status(&current_state);
    printf("Current environment state: %s\n",
           current_state == FCA_DAY_STATE ? "DAY" : "NIGHT");
    // test IR LED
    if(current_state == FCA_DAY_STATE)
        ret = fca_set_led_lighting(FCA_LIGHTING_LED_IR,1);
    else
        ret = fca_set_led_lighting(FCA_LIGHTING_LED_IR,0);
    printf("fca_set_led_lighting: %d\n", ret);
    sleep(5);

    // release
    ret = fca_dn_mode_resource_release();
    printf("fca_dn_mode_resource_release: %d\n", ret);

    // stop record
    if(media_file1)
        stop_recording(&media_file1);
    ret = fca_video_in_uninit();
    printf("fca_video_in_uninit: %d\n", ret);
    return;
}
void test_wifi_sta()
{
    int ret =0;
    char mac[18]={0};
    ret =fca_wifi_get_mac(mac,18);
    printf("fca_wifi_get_mac,mac:%s,ret:%d\n",mac,ret);

    bool connnect_status =false;
    ret =fca_wifi_get_status("wlan0",&connnect_status);
    printf("fca_wifi_get_status,connnect_status:%d,ret:%d\n",connnect_status,ret);

    wifi_network_info_t networks[20]={0};
    ret =fca_wifi_scan(&networks,20);
    printf("fca_wifi_scan,ret:%d\n",ret);
    for(int i=0;i<ret;i++)
    {
        printf("index:%d,ssid:%s,encrypt_mode:%s,signal:%d,BSSID:%s\n",i,networks[i].ssid,networks[i].encrypt_mode,networks[i].signal_strength,networks[i].mac_address);
    }

    StaticIPConfig static_config={0};
    strcpy(static_config.ip_address,"192.168.5.100");
    strcpy(static_config.subnet_mask,"255.255.255.0");
    strcpy(static_config.gateway,"192.168.5.1");
    strcpy(static_config.dns1,"8.8.8.8");
    ret =fca_wifi_set_static_ip("wlan0",&static_config);
    printf("fca_wifi_set_static_ip,ret:%d\n",ret);
    system("ifconfig");
    ret =fca_wifi_connect("wlan0","vht","ABC123456");
    printf("fca_wifi_connect,ret:%d\n",ret);
    sleep(3);
    ret =fca_wifi_get_status("wlan0",&connnect_status);
    printf("fca_wifi_get_status,connnect_status:%d,ret:%d\n",connnect_status,ret);
    sleep(5);
    ret =fca_wifi_disconnect("wlan0");
    printf("fca_wifi_disconnect,ret:%d\n",ret);
    
}
void test_wifi_AP()
{
    int ret=0;
    ret=fca_wifi_start_ap_mode("wlan0","tts","abc123456","192.168.5.100");
    printf("fca_wifi_start_ap_mode,ret:%d\n",ret);
    sleep(60);
    ret=fca_wifi_stop_ap_mode("wlan0");
    printf("fca_wifi_stop_ap_mode,ret:%d\n",ret);
    
}


int Test_gpio() {
    int ret=0;
    fca_led_status_t set_status = {0};
    fca_led_status_t get_status = {0};
    FCA_BTN_STATUS reset_status, user_status;
    int i=0;

    printf("=== Starting GPIO Test with LED Get Validation ===\n");

    // Test calling get function when uninitialized (expected to fail)
    get_status.color = FCA_LED_COLOR_GREEN;
    ret = fca_gpio_led_status_get(&get_status);
    if (ret == FCA_ERROR_NOT_INITIALIZED) {
        printf("PASS: fca_gpio_led_status_get (uninitialized) returns correct error\n");
    } else {
        printf("FAIL: fca_gpio_led_status_get (uninitialized) unexpected ret=%d\n", ret);
        return ret;
    }

    // Initialize GPIO
    ret = fca_gpio_key_init();
    if (ret != 0) {
        printf("FAIL: fca_gpio_key_init failed! ret=%d\n", ret);
        return ret;
    }
    printf("PASS: fca_gpio_key_init success\n\n");

    // Test 1: Set green LED to ON, verify get result
    set_status.color = FCA_LED_COLOR_GREEN;
    set_status.mode = FCA_LED_MODE_ON;
    set_status.interval = 0;
    ret = fca_gpio_led_status_set(set_status);
    if (ret != 0) {
        printf("FAIL: Set GREEN LED ON failed! ret=%d\n", ret);
        fca_gpio_key_deinit();
        return ret;
    }
    
    // Read green LED status
    memset(&get_status, 0, sizeof(fca_led_status_t));
    get_status.color = FCA_LED_COLOR_GREEN; // Specify LED color to read
    ret = fca_gpio_led_status_get(&get_status);
    if (ret < 0) {
        printf("FAIL: Get GREEN LED status failed! ret=%d\n", ret);
        fca_gpio_key_deinit();
        return ret;
    }
    // Verify read result matches set value
    if (get_status.mode == set_status.mode && get_status.interval == set_status.interval) {
        printf("PASS: GREEN LED get status matches (mode=%d, interval=%d)\n", 
               get_status.mode, get_status.interval);
    } else {
        printf("FAIL: GREEN LED get mismatch! Expected (mode=%d, interval=%d), Got (mode=%d, interval=%d)\n",
               set_status.mode, set_status.interval, get_status.mode, get_status.interval);
        fca_gpio_key_deinit();
        return -1;
    }

    // Test 2: Set white LED to BLINKING, verify get result
    set_status.color = FCA_LED_COLOR_WHITE;
    set_status.mode = FCA_LED_MODE_BLINKING;
    set_status.interval = 300; // 300ms interval
    ret = fca_gpio_led_status_set(set_status);
    if (ret != 0) {
        printf("FAIL: Set WHITE LED BLINK failed! ret=%d\n", ret);
        fca_gpio_key_deinit();
        return ret;
    }
    
    // Read white LED status
    memset(&get_status, 0, sizeof(fca_led_status_t));
    get_status.color = FCA_LED_COLOR_WHITE; // Specify LED color to read
    ret = fca_gpio_led_status_get(&get_status);
    if (ret < 0) {
        printf("FAIL: Get WHITE LED status failed! ret=%d\n", ret);
        fca_gpio_key_deinit();
        return ret;
    }
    // Verify read result matches set value
    if (get_status.mode == set_status.mode && get_status.interval == set_status.interval) {
        printf("PASS: WHITE LED get status matches (mode=%d, interval=%d)\n", 
               get_status.mode, get_status.interval);
    } else {
        printf("FAIL: WHITE LED get mismatch! Expected (mode=%d, interval=%d), Got (mode=%d, interval=%d)\n",
               set_status.mode, set_status.interval, get_status.mode, get_status.interval);
        fca_gpio_key_deinit();
        return -1;
    }

    // Test 3: Error scenario - Pass NULL pointer to get function
    ret = fca_gpio_led_status_get(NULL);
    if (ret == FCA_ERROR_INVALID_PARAM) {
        printf("PASS: fca_gpio_led_status_get (NULL) returns correct error\n");
    } else {
        printf("FAIL: fca_gpio_led_status_get (NULL) unexpected ret=%d\n", ret);
        fca_gpio_key_deinit();
        return ret;
    }

    // Test 4: Error scenario - Pass invalid LED color
    memset(&get_status, 0, sizeof(fca_led_status_t));
    get_status.color = FCA_LED_COLOR_MAX; // Invalid color
    ret = fca_gpio_led_status_get(&get_status);
    if (ret == FCA_ERROR_INVALID_PARAM) {
        printf("PASS: fca_gpio_led_status_get (invalid color) returns correct error\n");
    } else {
        printf("FAIL: fca_gpio_led_status_get (invalid color) unexpected ret=%d\n", ret);
        fca_gpio_key_deinit();
        return ret;
    }

    // Loop to read button status (periodically verify LED status)
    printf("\nStart button test (20 loops, 500ms interval)...\n");
    printf("Please press/release buttons during testing\n");
    for (i = 0; i < 20; i++) {
        // Verify LED status every 5 loops
        if (i % 5 == 0) {
            // Verify green LED remains ON
            memset(&get_status, 0, sizeof(fca_led_status_t));
            get_status.color = FCA_LED_COLOR_GREEN;
            ret = fca_gpio_led_status_get(&get_status);
            if (ret != 0) {
                printf("Loop %d: Get GREEN LED failed! ret=%d\n", i+1, ret);
            } else if (get_status.mode != FCA_LED_MODE_ON) {
                printf("Loop %d: GREEN LED status changed unexpectedly! mode=%d\n", i+1, get_status.mode);
            }

            // Verify white LED remains BLINKING
            memset(&get_status, 0, sizeof(fca_led_status_t));
            get_status.color = FCA_LED_COLOR_WHITE;
            ret = fca_gpio_led_status_get(&get_status);
            if (ret != 0) {
                printf("Loop %d: Get WHITE LED failed! ret=%d\n", i+1, ret);
            } else if (get_status.mode != FCA_LED_MODE_BLINKING || get_status.interval != 300) {
                printf("Loop %d: WHITE LED status changed unexpectedly! mode=%d, interval=%d\n", 
                       i+1, get_status.mode, get_status.interval);
            }
        }

        //Read button status
        ret = fca_get_button_status(FCA_BTN_RESET, &reset_status);
        if (ret != 0) {
            printf("Loop %d: Read RESET button failed! ret=%d\n", i+1, ret);
        } else {
            printf("Loop %d: RESET=%s | ", i+1,
                   reset_status == FCA_BTN_STATUS_PRESS ? "PRESSED" : "RELEASED");
        }

        ret = fca_get_button_status(FCA_BTN_USER, &user_status);
        if (ret != 0) {
            printf("Read USER button failed! ret=%d\n", ret);
        } else {
            printf("USER=%s\n",
                   user_status == FCA_BTN_STATUS_PRESS ? "PRESSED" : "RELEASED");
        }

        usleep(500000); // 500ms interval
    }

    //Test 5: Set LEDs to OFF, verify get result
    set_status.color = FCA_LED_COLOR_GREEN;
    set_status.mode = FCA_LED_MODE_OFF;
    set_status.interval = 0;
    ret = fca_gpio_led_status_set(set_status);
    set_status.color = FCA_LED_COLOR_WHITE;
    set_status.mode = FCA_LED_MODE_OFF;
    fca_gpio_led_status_set(set_status);

    memset(&get_status, 0, sizeof(fca_led_status_t));
    get_status.color = FCA_LED_COLOR_GREEN;
    ret = fca_gpio_led_status_get(&get_status);
    if (ret == 0 && get_status.mode == FCA_LED_MODE_OFF) {
        printf("\nPASS: GREEN LED OFF status verified\n");
    } else {
        printf("\nFAIL: GREEN LED OFF status mismatch! ret=%d, mode=%d\n", ret, get_status.mode);
    }

    // Deinitialize
    ret = fca_gpio_key_deinit();
    if (ret != 0) {
        printf("FAIL: fca_gpio_key_deinit failed! ret=%d\n", ret);
        return ret;
    }
    printf("PASS: fca_gpio_key_deinit success\n");

    printf("=== GPIO Test with LED Get Validation Completed ===\n");
    return 0;
}

void test_watchdog_init() {
    // Test initialization
    int init_ret = fca_sys_watchdog_init(10);
    if (init_ret == 0) {
        printf("Watchdog initialized successfully\n");
    } else {
        printf("Watchdog initialization failed, error code: %d\n", init_ret);
        return;
    }


    while (1)
    {
        sleep(1);
    }
    
}
void test_watchdog_feed()
{
    int init_ret = fca_sys_watchdog_init(10);
    if (init_ret == 0) {
        printf("Watchdog initialized successfully\n");
    } else {
        printf("Watchdog initialization failed, error code: %d\n", init_ret);
        return;
    }

    int count = 10;
    while (count) {
        init_ret = fca_sys_watchdog_refresh();
        if (init_ret != 0) {
            printf("watchdog feed failed,ret:%d\n", init_ret);
            break;
        }
        printf("waiting 5s,count:%d\n", --count);
        sleep(5);
    }
}
void test_watchdog_stop()
{
    int init_ret = fca_sys_watchdog_init(10);
    if (init_ret == 0) {
        printf("Watchdog initialized successfully\n");
    } else {
        printf("Watchdog initialization failed, error code: %d\n", init_ret);
        return;
    }
    // Test stop
    int stop_ret = fca_sys_watchdog_stop_block();
    if (stop_ret == 0) {
        printf("Watchdog stopped successfully\n");
    } else {
        printf("Failed to stop watchdog, error code: %d\n", stop_ret);
    }
    printf("waiting 30s\n");
    sleep(30);
}

int main() {
    signal(SIGSEGV, recvSignal);  
	signal(SIGABRT, recvSignal);  
	signal(SIGKILL, recvSignal);  
	signal(SIGINT, recvSignal);   
	signal(SIGTERM, recvSignal); 
    printf("Starting FCA API test...\n");

    // test_video();
    // test_audio();
    // printf ("Test wifi sta");
    // test_wifi_sta();
    // printf ("Test wifi AP mode");
    // test_wifi_AP();
    // Test_OTA();
    // printf ("Test Ir Cut ................................................");
    // Test_IrCut();
    // printf ("Test GPIO ....................................................");
    Test_gpio();
    // test_watchdog_init();
    // test_watchdog_feed();
    // test_watchdog_stop();

    printf("\nTest completed!\n");
    return 0;
}