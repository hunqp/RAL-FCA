#ifndef ODM_API_VERSION_H
#define ODM_API_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif
/*------------------------------------------------------------------------------
 * Version Information
 *----------------------------------------------------------------------------*/
/**
 * @def FCA_API_VERSION_STRING
 * @brief String representation of FCA API version
 */
#define FCA_API_VERSION_STRING "V1.01.03"

/* Version history:
 * V1.01.00 (2025-10-23):
 *  Version Description: This version has a residual issue where the sub-stream abnormally fails to output streams, resulting in the temporary unavailability of QR code scanning and screenshot functions.
    It does not support the configuration or usage of the third stream.
    The audio input configuration only supports the setting of index 0.
    For audio output, testing at 8k or 16k is currently recommended; other higher sampling rates may malfunction when using AAC or G711 formats.
    
 * V1.01.01 (2025-10-24):
 * 1.Fixed the issue of secondary stream initialization failure and video stream loading failure. The QR code and screenshot-related interfaces have been verified to be normal and can be used properly.
 * 2.Fixed the error reporting issue with audio capture timestamps.
 * 3.For this update, the device needs to re-upgrade ovflash. Please confirm that the driver update is successful before verifying the above functions.

 * V1.01.02 (2025-11-1): 
 * 1.Update the WIFI-related functions in the network module; please refer to the usage of the test_wifi_sta function and test_wifi_ap function in test_all.
 * 2.Wired network configuration-related functions are not supported; all calls to these functions will return the error code FCA_ERROR_NOT_SUPPORTED (-3).
 * 
 * V1.01.03 (2025-11-7):
 * 1.Add the len field to the fca_sys_set_uboot_passwd function and the fca_sys_set_root_passwd function.
 * 2.Add a new OTA upgrade function: pre-store the version-specific upgrade files in the device's SD card,
 *   modify the file name specified in fca_sys_fw_ota within test_all, 
 *   run the test_all file to check if the function returns 0 as expected, and verify if the version number in the /etc/sysversion file updates to the expected version after the device restarts.
 */

/*----------------------------------------------------------------------------*/
/* Common Definitions                                                         */
/*----------------------------------------------------------------------------*/

/**
 * @defgroup common_defs Common Definitions
 * @brief Shared data types and constants used across modules
 * @{
 */
#ifdef __cplusplus
}
#endif

#endif
